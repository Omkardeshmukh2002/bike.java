create database bike_selling_system;

use bike_selling_system;

drop table customer;

create table customer(
	custid int primary key,
    custname varchar(50),
    Address varchar(50),
    mobileno varchar(50),
    custdob varchar(50),
    gender varchar(50),
    Biketype varchar(50),
    Colour varchar(50)
);

create table bike(
	Bikeid int primary key,
    Bikename varchar(50),
    Milage varchar(50),
    Fuelcapacity varchar(50),
    Warranty varchar(50),
    Weight varchar(50),
    Price varchar(50),
    Colour varchar(50)
);

create table Supplier(
	Supplierid int primary key,
    Suppliername varchar(50),
    Address varchar(50),
    Mobileno varchar(50),
    Supplierdob varchar(50),
    Gender varchar(50),
    Biketype int,
    Color varchar(50)
);

create table Order1(
	Orderid int primary key,
    Bikename varchar(50),
    Quantity varchar(50),
    Colour varchar(50)
);

create table Stocks(
	stockid int primary key,
    Bikename varchar(50),
    Quantity varchar(50)
);

ALTER TABLE Quotation CHANGE Warranty warrenty varchar(50);
ALTER TABLE Supplier
MODIFY COLUMN Biketype varchar(50);

create table Quotation(
	Quotationid int primary key,
    Bikename varchar(50),
    Milage varchar(50),
    Fuelcapacity varchar(50),
    Warranty varchar(50),
    Weight varchar(50),
    Price varchar(50),
    Colour varchar(50)
);

drop table bill;

create table bill(
	billnumber int primary key,
    cname varchar(50),
    bname varchar(50),
    price varchar(50),
    bdate varchar(50)
);











select * from customer;
ALTER TABLE customer CHANGE Colour color varchar(50);

ALTER TABLE Customer
ADD Bikename varchar(50);


insert into customer(name, address, mobile_number, date_of_birth, gender, bike_id, bike_type, color) values('sfsff','fsdfsf','33434','23423424','Male','hero','red');
ALTER TABLE customer CHANGE name custname varchar(50);

ALTER TABLE customer CHANGE name custname varchar(50);
ALTER TABLE customer CHANGE address Address varchar(50);
ALTER TABLE customer CHANGE mobile_number mobileno varchar(50);
ALTER TABLE customer CHANGE date_of_birth custdob varchar(50);
ALTER TABLE customer CHANGE gender gender varchar(50);
ALTER TABLE customer CHANGE gender gender varchar(50);



