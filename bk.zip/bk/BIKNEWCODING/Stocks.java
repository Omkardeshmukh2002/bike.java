import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

class Stocks extends Frame implements ActionListener, ItemListener {

	Label ltitle, lpid, lpname, lbno;

	TextField tfid1, tfpname, tfbno;

	// Choice time1,date1,month1,year1,bal;

	JPanel p;
	String m;

	Button badd, bdelete, bmodify, bsave, bsearch, bclose;

	Font f1, f2, f3;
	Connection con;
	Statement st, st1;
	ResultSet rs, rs1;
	char check = 'X';

	public Stocks() {
		setSize(1500, 900);
		setVisible(true);
		setBackground(Color.magenta);
		setLayout(null);
		f1 = new Font("Arial Black", Font.BOLD, 31);
		f2 = new Font("Arial", Font.BOLD, 21);
		f3 = new Font("Arial", Font.BOLD, 16);

		setTitle("Stock Details");
		ltitle = new Label("Stock Information Forms");
		add(ltitle);
		ltitle.setFont(f1);
		ltitle.setBackground(Color.blue);
		ltitle.setForeground(Color.yellow);

		lpid = new Label("Stock ID");
		add(lpid);
		lpid.setFont(f2);

		lpname = new Label("Bike Name");
		add(lpname);
		lpname.setFont(f2);

		lbno = new Label("Stock Quantity");
		add(lbno);
		lbno.setFont(f2);

		// lbdate=new Label("Bill Pay Date");
		// add(lbdate);
		// lbdate.setFont(f2);

		// lttime=new Label("Total Time");
		// add(lttime);
		// lttime.setFont(f2);

		// ltbal=new Label("Total Balance");
		// add(ltbal);
		// ltbal.setFont(f2);

		// date1=new Choice();
		// date1.add("Select");
		// date1.add("1"); date1.add("2"); date1.add("3");date1.add("4");
		// date1.add("5"); date1.add("6");date1.add("7");
		// date1.add("8");date1.add("9");date1.add("10");
		// date1.add("11");date1.add("12");date1.add("13");date1.add("14");date1.add("15");
		// date1.add("16");date1.add("17");date1.add("18");date1.add("19");date1.add("20");
		// date1.add("21");date1.add("22");date1.add("23");date1.add("24");date1.add("25");
		// date1.add("26");date1.add("27");date1.add("28");date1.add("29");date1.add
		// ("30");date1.add("31");
		// add(date1);
		// date1.addItemListener(this);

		// month1=new Choice();
		// month1.add("Select");
		// month1.add("Jan"); month1.add("Feb"); month1.add("Mar");month1.add("April");
		// month1.add("May"); month1.add("June");month1.add("Jully");
		// month1.add("Aug");month1.add("Sept");month1.add("Oct");
		// month1.add("Nov");month1.add("Dec");
		// add(month1);
		// month1.addItemListener(this);

		// year1=new Choice();
		// year1.add("Select");
		// year1.add("2010");year1.add("2011");
		// year1.add("2012");year1.add("2013");year1.add("2014");
		// year1.add("2015");year1.add("2016");
		// add(year1);
		// year1.addItemListener(this);

		// time1=new Choice();
		// time1.add("Select");
		// time1.add("15 min"); time1.add("30 min"); time1.add("1 hour");time1.add("2
		// hour"); time1.add("3 hour");
		// add(time1);
		// time1.addItemListener(this);

		// bal=new Choice();
		// bal.add("Select");
		// bal.add("Rs.25/-"); bal.add("Rs.50/-"); bal.add("Rs.100/-");
		// bal.add("Rs.200/-");bal.add("Rs.300/-");
		// add(bal);
		// bal.addItemListener(this);

		tfid1 = new TextField();
		add(tfid1);
		tfid1.setFont(f3);

		tfpname = new TextField();
		add(tfpname);
		tfpname.setFont(f3);

		tfbno = new TextField();
		add(tfbno);
		tfbno.setFont(f3);

		// tfbdate=new TextField();
		// add(tfbdate);
		// tfbdate.setFont(f3);

		// tfttime=new TextField();
		// add(tfttime);
		// tfttime.setFont(f3);

		// tftbal=new TextField();
		// add(tftbal);
		// tftbal.setFont(f3);

		badd = new Button("Add");
		bdelete = new Button("Delete");
		bmodify = new Button("Modify");
		bsave = new Button("Save Form");
		bsearch = new Button("Search");
		bclose = new Button("Close");

		add(badd);
		badd.setFont(f3);
		badd.setForeground(Color.white);
		badd.setBackground(Color.blue);

		add(bdelete);
		bdelete.setFont(f3);
		bdelete.setForeground(Color.white);
		bdelete.setBackground(Color.blue);

		add(bmodify);
		bmodify.setFont(f3);
		bmodify.setForeground(Color.white);
		bmodify.setBackground(Color.blue);

		add(bsave);
		bsave.setFont(f3);
		bsave.setForeground(Color.white);
		bsave.setBackground(Color.blue);

		add(bsearch);
		bsearch.setFont(f3);
		bsearch.setForeground(Color.white);
		bsearch.setBackground(Color.blue);

		add(bclose);
		bclose.setFont(f3);
		bclose.setForeground(Color.white);
		bclose.setBackground(Color.blue);

		// date1.addItemListener(this);
		// month1.addItemListener(this);
		// year1.addItemListener(this);
		// time1.addItemListener(this);
		// bal.addItemListener(this);

		badd.addActionListener(this);
		bdelete.addActionListener(this);
		bmodify.addActionListener(this);
		bsearch.addActionListener(this);
		bclose.addActionListener(this);
		bsave.addActionListener(this);

		ltitle.setBounds(250, 70, 500, 50);
		lpid.setBounds(120, 150, 280, 30);
		tfid1.setBounds(450, 150, 300, 30);
		lpname.setBounds(120, 200, 250, 30);
		tfpname.setBounds(450, 200, 300, 30);
		lbno.setBounds(120, 250, 250, 30);
		tfbno.setBounds(450, 250, 300, 30);

		// lbdate.setBounds(120,300,250,30);
		// date1.setBounds(450,300,60,30);
		// year1.setBounds(650,300,90,30);
		// month1.setBounds(540,300,90,30);
		// tfbdate.setBounds(800,300,120,30);
		// lttime.setBounds(120,350,300,30);
		// rbMale.setBounds(450,500,150,30);
		// rbFemale.setBounds(670,500,150,30);
		// time1.setBounds(450,350,150,30);
		// tfttime.setBounds(800,350,100,30);
		// ltbal.setBounds(120,400,250,30);
		// bal.setBounds(450,400,250,30);
		// tftbal.setBounds(800,400,180,30);
		JLabel jl = new JLabel(new ImageIcon("golden-sparkles-abstract-hd-wallpaper-1920x1200-6623.jpg"));
		add(jl);
		jl.setBounds(0, 0, 1500, 900);

		badd.setBounds(40, 320, 140, 30);
		bdelete.setBounds(210, 320, 140, 30);
		bmodify.setBounds(380, 320, 140, 30);
		bsave.setBounds(550, 320, 140, 30);
		bsearch.setBounds(720, 320, 120, 30);
		bclose.setBounds(870, 320, 110, 30);

		tfid1.setEnabled(false);
		tfpname.setEnabled(false);
		tfbno.setEnabled(false);

		// date1.setEnabled(false);
		// month1.setEnabled(false);
		// year1.setEnabled(false);
		// time1.setEnabled(false);
		// bal.setEnabled(false);
		// tfbdate.setEnabled(false);
		// tfttime.setEnabled(false);
		// tftbal.setEnabled(false);

		try {
			Class.forName("com.mysql.jdbc.Driver");
      		con = DriverManager.getConnection("jdbc:mysql://localhost/bike_selling_system", "root", "12345678");
			// con = DriverManager.getConnection("jdbc:odbc:college", "", "");
			st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			rs = st.executeQuery("select * from Stocks  order by sid");

			/*
			 * while(rs.next()) { //date1.addItem(rs.getString(6));
			 * //month1.addItem(rs.getString(7)); //year1.addItem(rs.getString(8));
			 * //gen.addItem(rs.getString(7)); //qual.addItem(rs.getString(8)); }
			 */
			JOptionPane.showMessageDialog(this, "Connection Made Successfully");
		} catch (Exception se) {
			se.printStackTrace();
			JOptionPane.showMessageDialog(this, "Problem When Maintaining Connection");
		}
	}

	public void itemStateChanged(ItemEvent ie) {

	}

	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == badd) {
			check = 'A';
			tfid1.setEnabled(true);
			tfpname.setEnabled(true);
			tfbno.setEnabled(true);

			// date1.setEnabled(true);
			// month1.setEnabled(true);
			// year1.setEnabled(true);
			// time1.setEnabled(true);
			// bal.setEnabled(true);
			try {
				st1 = con.createStatement();
				rs1 = st1.executeQuery("select count(sid) as count, max(sid)+1 as m_sid from Stocks ");
				while (rs1.next()) {
					if (rs1.getInt(1) == 0) {
						tfid1.setText("1");
					} else {
						tfid1.setText(String.valueOf(rs1.getInt(2)));
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(this, e);
			} // design.setEnabled(true);

		}

		else if (ae.getSource() == bdelete) {
			check = 'D';

			String s = JOptionPane.showInputDialog(this, "Enter ID No. Of That Stocks,Whose Data You Want To Delete");
			int pid = Integer.parseInt(s);
			int chk = searching(pid);
			if (chk == 1) {
				JOptionPane.showMessageDialog(this,
						"To Delete Record Of This  Stocks Permanently Click On SAVE Button");
			} else {
				JOptionPane.showMessageDialog(this, "Record Of Such a  Stocks Is Not Found,So Can't Delete Any Record");
			}
		}

		else if (ae.getSource() == bmodify) {
			check = 'M';
			String s = JOptionPane.showInputDialog(this, "Enter ID No. Of That  Stocks,Whose Data You Want To Modify");
			int pid = Integer.parseInt(s);
			int chk = searching(pid);
			if (chk == 1) {
				JOptionPane.showMessageDialog(this, "Make The Changes And Then Click On SAVE Button");
				tfid1.setEnabled(true);
				tfpname.setEnabled(true);
				tfbno.setEnabled(true);
				// tfbdate.setEnabled(true);
				// tfttime.setEnabled(true);
				// tftbal.setEnabled(true);

			} else {
				JOptionPane.showMessageDialog(this, "Record Of Such a Stocks Is Not Found,So Can't Modify Any Record");
			}
		}

		else if (ae.getSource() == bsearch) {
			String s = JOptionPane.showInputDialog(this, "Enter ID No. Of That  Stocks,Whose Data You Want To Search");
			int sid = Integer.parseInt(s);
			int chk = searching(sid);
			if (chk == 0) {
				JOptionPane.showMessageDialog(this, "Record Of Such a  StocksIs Not Found");
			}
		}

		else if (ae.getSource() == bsave) {
			if (check == 'A') {
				int pid = Integer.parseInt(tfid1.getText());
				String pname = tfpname.getText();
				int bno = Integer.parseInt(tfbno.getText());

				// String dt=date1.getSelectedItem();
				// String mt=month1.getSelectedItem();
				// String yr=year1.getSelectedItem();
				// String adate=dt+'/'+mt+'/'+yr;
				// String t=time1.getSelectedItem();
				// String b=bal.getSelectedItem();

				try {
					String str = "insert into Stocks  values(" + pid + ",'" + pname + "'," + bno + ")";
					st = con.createStatement();
					st.executeUpdate(str);
					JOptionPane.showMessageDialog(this, "Record Is Added Successfully");
					rs = st.executeQuery("select * from Stocks  order by  sid");

				}

				catch (Exception se) {
					se.printStackTrace();
					JOptionPane.showMessageDialog(this, "Problem When Showing Added Record");
				}

			}

			else if (check == 'D') {
				try {
					PreparedStatement psdelete = con.prepareStatement("delete from Stocks  where  sid=?");
					psdelete.setInt(1, Integer.parseInt(tfid1.getText()));
					psdelete.executeUpdate();
					JOptionPane.showMessageDialog(this, " Record Is deleted Successfully");
					rs = st.executeQuery("select * from Stocks  order by sid");
				}

				catch (Exception ac) {
					ac.printStackTrace();
					JOptionPane.showMessageDialog(this, "Problem When Deleting Record");
				}
				tfid1.setText("");
				tfpname.setText("");
				tfbno.setText("");
				// tfbdate.setText("");
				// tfttime.setText("");
				// tftbal.setText("");

			}

			else if (check == 'M') {
				try {
					PreparedStatement psmodify = con
							.prepareStatement("Update Stocks  set bikename=?,quantity=? where sid=?");
					psmodify.setString(1, tfpname.getText());
					psmodify.setInt(2, Integer.parseInt(tfbno.getText()));
					// psmodify.setString(3,tfbdate.getText());
					// psmodify.setString(4,tfttime.getText());
					// psmodify.setString(5,tftbal.getText());
					psmodify.setInt(3, Integer.parseInt(tfid1.getText()));
					psmodify.executeUpdate();
					JOptionPane.showMessageDialog(this, " Record Is Modified Successfully");
					rs = st.executeQuery("select * from Stocks order by sid");
				} catch (SQLException ac) {
					ac.printStackTrace();
					JOptionPane.showMessageDialog(this, "Problem When Modifing Record");
				}
				tfid1.setText("");
				tfpname.setText("");
				tfbno.setText("");
				// tfbdate.setText("");
				// tfttime.setText("");
				// tftbal.setText("");

				tfid1.setEnabled(false);
				tfpname.setEnabled(false);
				tfbno.setEnabled(false);
				// tfbdate.setEnabled(false);
				// tfttime.setEnabled(false);
				// tftbal.setEnabled(false);

			}

		}

		else if (ae.getSource() == bclose) {
			dispose();
		}

	}

	int searching(int pid) {
		int chk = 0;
		try {
			int v1 = 0;
			String v2 = "", v3 = "", v4 = "", v5 = "", v6 = "";

			while (rs.next()) {
				v1 = rs.getInt(1);
				v2 = rs.getString(2);
				v3 = rs.getString(3);
				// v4=rs.getString(4);
				// v5=rs.getString(5);
				// v6=rs.getString(6);

				// v10=qual.getSelectedItem();
				// v11=rs.getString(9);

				if (v1 == pid) {
					tfid1.setText(String.valueOf(v1));
					tfpname.setText(v2);
					tfbno.setText(v3);
					// tfbdate.setText(v4);
					// tfttime.setText(v5);
					// tftbal.setText(v6);

					chk = 1;
					break;
				}
			}
			rs.first();
			rs.previous();
		}

		catch (Exception se) {
			se.printStackTrace();
			JOptionPane.showMessageDialog(this, "Problems When Searching a Admin Record");
		}
		return (chk);
	}

	public static void main(String args[]) {
		Stocks b = new Stocks();
		b.setVisible(true);
		b.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				System.exit(0);
			}
		});
	}
}
