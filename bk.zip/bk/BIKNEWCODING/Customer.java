import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Choice.*;
import java.sql.*;
import java.awt.TextField.*;

class Customer extends Frame implements ActionListener, ItemListener {
  Label ltitle, lid, lname, laddr, lmobno, ldob, lgen, lqual, lcolor;
  TextField tfid1, taaddr, tfname, tfmobno, tfsal, tfdob, tfqual;
  // TextArea taaddr;
  Choice date1, month1, year1, gen, qual, design, color1;
  JPanel p;
  String m;
  Button badd, bdelete, bmodify, bsave, bsearch, bclose;
  Font f1, f2, f3;
  Connection con;
  Statement st, st1;
  ResultSet rs, rs1;
  char check = 'X';

  public Customer() {
    setSize(1000, 750);
    setVisible(true);
    setBackground(Color.pink);
    setLayout(null);
    f1 = new Font("Arial Black", Font.BOLD, 35);
    f2 = new Font("Arial", Font.BOLD, 21);
    f3 = new Font("Arial", Font.BOLD, 16);
    setTitle("Customer Details");
    ltitle = new Label("Customer Information Forms");
    add(ltitle);
    ltitle.setFont(f1);

    ltitle.setForeground(Color.blue);

    lid = new Label("Customer ID");
    add(lid);
    lid.setFont(f2);

    lname = new Label("Customer Name");
    add(lname);
    lname.setFont(f2);

    laddr = new Label("Customer Address");
    add(laddr);
    laddr.setFont(f2);

    lmobno = new Label("Customer Mobile Number");
    add(lmobno);
    lmobno.setFont(f2);

    ldob = new Label("Customer Date-Of-Birth  ");
    add(ldob);
    ldob.setFont(f2);

    lgen = new Label("Customer Gender");
    add(lgen);
    lgen.setFont(f2);

    lqual = new Label("Bike Type ");
    add(lqual);
    lqual.setFont(f2);

    lcolor = new Label("Color");
    add(lcolor);
    lcolor.setFont(f2);
    color1 = new Choice();
    color1.add("select");
    color1.add("red");
    color1.add("blue");
    color1.add("green");
    color1.add("pink");
    color1.add("yellow");
    color1.add("black");
    color1.add("white");
    add(color1);
    color1.addItemListener(this);

    qual = new Choice();
    qual.add("Select");
    qual.add("hero");
    qual.add("passion");
    qual.add("platina");
    qual.add("pulser");
    qual.add("ZMR");
    qual.add("Boxer");
    qual.add("Karizma");
    qual.add("Delux");
    qual.add("Glamour");
    qual.add("Splender");
    add(qual);
    qual.addItemListener(this);

    gen = new Choice();
    gen.add("Select");
    gen.add("Male");
    gen.add("Female");
    add(gen);
    gen.addItemListener(this);

    tfid1 = new TextField();
    add(tfid1);
    tfid1.setFont(f3);

    tfname = new TextField();
    add(tfname);
    tfname.setFont(f3);

    taaddr = new TextField();
    add(taaddr);
    taaddr.setFont(f3);

    tfmobno = new TextField();
    add(tfmobno);
    tfmobno.setFont(f3);

    // tfsal=new TextField();
    // add(tfsal);
    // tfsal.setFont(f3);

    tfdob = new TextField();
    add(tfdob);
    tfdob.setFont(f3);

    // tfqual=new TextField();
    // add(tfqual);
    // tfqual.setFont(f3);

    badd = new Button("Add");
    bdelete = new Button("Delete");
    bmodify = new Button("Modify");
    bsave = new Button("Save Form");
    bsearch = new Button("Search");
    bclose = new Button("Close Form");

    add(badd);
    badd.setFont(f3);
    badd.setForeground(Color.black);
    // badd.setBackground(Color.blue);

    add(bdelete);
    bdelete.setFont(f3);
    bdelete.setForeground(Color.black);
    // bdelete.setBackground(Color.blue);

    add(bmodify);
    bmodify.setFont(f3);
    bmodify.setForeground(Color.black);
    // bmodify.setBackground(Color.blue);

    add(bsave);
    bsave.setFont(f3);
    bsave.setForeground(Color.black);
    // bsave.setBackground(Color.blue);

    add(bsearch);
    bsearch.setFont(f3);
    bsearch.setForeground(Color.black);
    // bsearch.setBackground(Color.blue);

    add(bclose);
    bclose.setFont(f3);
    bclose.setForeground(Color.black);
    // bclose.setBackground(Color.blue);

    badd.addActionListener(this);
    bdelete.addActionListener(this);
    bmodify.addActionListener(this);
    bsearch.addActionListener(this);
    bclose.addActionListener(this);
    bsave.addActionListener(this);

    ltitle.setBounds(250, 70, 500, 50);
    lid.setBounds(120, 150, 280, 30);
    tfid1.setBounds(500, 150, 300, 30);
    lname.setBounds(120, 200, 250, 30);
    tfname.setBounds(500, 200, 300, 30);
    laddr.setBounds(120, 250, 250, 30);
    taaddr.setBounds(500, 250, 300, 30);
    lmobno.setBounds(120, 300, 270, 30);
    tfmobno.setBounds(500, 300, 270, 30);

    // ldeptproj.setBounds(120,400,370,30);
    // tfdept.setBounds(500,400,80,30);
    // tfprojname.setBounds(600,400,200,30);
    ldob.setBounds(120, 350, 250, 30);

    tfdob.setBounds(500, 350, 200, 30);
    lgen.setBounds(120, 400, 300, 30);
    gen.setBounds(500, 400, 150, 30);

    lqual.setBounds(120, 450, 250, 30);
    qual.setBounds(500, 450, 230, 30);
    // tfqual.setBounds(830,550,150,30);
    lcolor.setBounds(120, 500, 270, 30);
    color1.setBounds(500, 500, 230, 30);

    badd.setBounds(40, 600, 140, 30);
    bdelete.setBounds(210, 600, 140, 30);
    bmodify.setBounds(380, 600, 140, 30);
    bsave.setBounds(550, 600, 140, 30);
    bsearch.setBounds(720, 600, 120, 30);
    bclose.setBounds(870, 600, 110, 30);

    tfid1.setEnabled(false);
    tfname.setEnabled(false);
    taaddr.setEnabled(false);
    tfmobno.setEnabled(false);

    gen.setEnabled(false);
    qual.setEnabled(false);
    // design.setEnabled(false);
    tfdob.setEnabled(false);
    // tfgen.setEnabled(false);
    // tfqual.setEnabled(false);
    color1.setEnabled(false);
    // tfdesign.setEnabled(false);

    try {
      Class.forName("com.mysql.jdbc.Driver");
      con = DriverManager.getConnection("jdbc:mysql://localhost/bike_selling_system", "root", "12345678");
      // con=DriverManager.getConnection("jdbc:odbc:college");
      st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
      rs = st.executeQuery("select * from Customer order by custid");
      JOptionPane.showMessageDialog(this, "Connection Made Successfully");
    } catch (Exception se) {
      se.printStackTrace();
      System.out.println(se);
      JOptionPane.showMessageDialog(this, "Problem When Maintaining Connection");
    }
  }

  public void itemStateChanged(ItemEvent ie) {

  }

  public void actionPerformed(ActionEvent ae) {
    if (ae.getSource() == badd) {
      check = 'A';
      tfid1.setEnabled(true);
      tfname.setEnabled(true);
      taaddr.setEnabled(true);
      tfmobno.setEnabled(true);
      // tfdept.setEnabled(true);
      // tfprojname.setEnabled(true);
      /*
       * date1.setEnabled(true); month1.setEnabled(true);
       */
      tfdob.setEnabled(true);
      qual.setEnabled(true);
      gen.setEnabled(true);
      // year1.setEnabled(true);
      color1.setEnabled(true);
      // design.setEnabled(true);
      try {
        st1 = con.createStatement();
        rs1 = st1.executeQuery("select count(custid) as count, max(custid)+1 as m_custid from Customer");
        while (rs1.next()) {
          if (rs1.getInt(1) == 0) {
            tfid1.setText("1");
          } else {
            tfid1.setText(String.valueOf(rs1.getInt(2)));
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
        System.out.println(e);
        JOptionPane.showMessageDialog(this, e);
      }

    } else if (ae.getSource() == bdelete) {
      check = 'D';
      String s = JOptionPane.showInputDialog(this, "Enter ID No. Of That Customer,Whose Data You Want To Delete");
      int eid = Integer.parseInt(s);
      int chk = searching(eid);
      if (chk == 1) {
        JOptionPane.showMessageDialog(this, "To Delete Record Of This Customer Permanently Click On SAVE Button");
      } else {
        JOptionPane.showMessageDialog(this, "Record Of Such a Customer Is Not Found,So Can't Delete Any Record");
      }
    }

    else if (ae.getSource() == bmodify) {
      check = 'M';
      String s = JOptionPane.showInputDialog(this, "Enter ID No. Of That Customer,Whose Data You Want To Modify");
      int eid = Integer.parseInt(s);
      int chk = searching(eid);
      if (chk == 1) {
        JOptionPane.showMessageDialog(this, "Make The Changes And Then Click On SAVE Button");
        tfid1.setEnabled(true);
        tfname.setEnabled(true);
        taaddr.setEnabled(true);
        tfmobno.setEnabled(true);
        // tfdept.setEnabled(true);
        // tfprojname.setEnabled(true);
        tfdob.setEnabled(true);
        gen.setEnabled(true);
        qual.setEnabled(true);
        color1.setEnabled(true);
        // design.setEnabled(true);

      } else {
        JOptionPane.showMessageDialog(this, "Record Of Such a Customer Is Not Found,So Can't Modify Any Record");
      }
    }

    else if (ae.getSource() == bsearch) {
      String s = JOptionPane.showInputDialog(this, "Enter ID No. Of That Customer,Whose Data You Want To Search");
      int eid = Integer.parseInt(s);
      int chk = searching(eid);
      if (chk == 0) {
        JOptionPane.showMessageDialog(this, "Record Of Such a Customer Is Not Found");
      }
    }

    else if (ae.getSource() == bsave) {
      if (check == 'A') {
        String id = tfid1.getText();
        String name = tfname.getText();
        String addr = taaddr.getText();
        String mobno = tfmobno.getText();
        // String d=tfdept.getText();
        // String p=tfprojname.getText();
        String edate = tfdob.getText();
        /*
         * String dt=date1.getSelectedItem(); String mt=month1.getSelectedItem(); String
         * yr=year1.getSelectedItem(); String edate=dt+'/'+mt+'/'+yr;
         */
        String q = qual.getSelectedItem();
        String g = gen.getSelectedItem();
        String col = color1.getSelectedItem();
        // String des=design.getSelectedItem();

        try {
          String str = "insert into Customer values(" + id + ",'" + name + "','" + addr + "','" + mobno + "','" + edate
              + "','" + g + "','" + q + "','" + col + "')";
          st = con.createStatement();
          st.executeUpdate(str);
          JOptionPane.showMessageDialog(this, "Record Is Added Successfully");
          rs = st.executeQuery("select * from Customer order by custid");
          tfid1.setText("");
          tfname.setText("");
          taaddr.setText("");
          tfmobno.setText("");
          // tfdept.setText("");
          // tfprojname.setText("");
          tfdob.setText("");
          gen.select("");
          qual.select("");
          color1.select("");
          // design.select("");

        } catch (Exception se) {
          se.printStackTrace();
          System.out.println(se);
          JOptionPane.showMessageDialog(this, "Problem When Showing Added Record");
        }

      }

      else if (check == 'D') {
        try {
          PreparedStatement psdelete = con.prepareStatement("delete from Customer where custid=?");
          psdelete.setInt(1, Integer.parseInt(tfid1.getText()));
          psdelete.executeUpdate();
          JOptionPane.showMessageDialog(this, " Record Is deleted Successfully");
          rs = st.executeQuery("select * from Customer order by custid");
        }

        catch (Exception ac) {
          ac.printStackTrace();
          System.out.println(ac);
          JOptionPane.showMessageDialog(this, "Problem When Deleting Record");
        }
        tfid1.setText("");
        tfname.setText("");
        taaddr.setText("");
        tfmobno.setText("");
        // tfdept.setText("");
        // tfprojname.setText("");
        tfdob.setText("");
        gen.select("");
        qual.select("");
        color1.select("");
        // design.select("");
      }

      else if (check == 'M') {
        try {
          PreparedStatement psmodify = con.prepareStatement(
              "Update Customer set custname=?,Address=?,mobileno=?,custdob=?,gender=?,Bikename=?,color=? where custid=?");
          System.out.println("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD");
          psmodify.setString(1, tfname.getText());
          psmodify.setString(2, taaddr.getText());
          psmodify.setString(3, tfmobno.getText());
          // psmodify.setString(4,tfdept.getText());
          // psmodify.setString(5,tfprojname.getText());
          psmodify.setString(4, tfdob.getText());
          psmodify.setString(5, gen.getSelectedItem());
          psmodify.setString(6, qual.getSelectedItem());
          psmodify.setString(7, color1.getSelectedItem());
          // psmodify.setString(10,design.getSelectedItem());
          psmodify.setInt(8, Integer.parseInt(tfid1.getText()));
          psmodify.executeUpdate();
          JOptionPane.showMessageDialog(this, " Record Is Modified Successfully");
          rs = st.executeQuery("select * from Customer order by custid");
        } catch (Exception ac) {
          ac.printStackTrace();
          System.out.println(ac);
          JOptionPane.showMessageDialog(this, "Problem When Modifing Record");
        }
        tfid1.setText("");
        tfname.setText("");
        taaddr.setText("");
        tfmobno.setText("");
        // tfdept.setText("");
        // tfprojname.setText("");
        tfdob.setText("");
        qual.select("");
        gen.select("");
        color1.select("");
        // design.select("");

        tfid1.setEnabled(false);
        tfname.setEnabled(false);
        taaddr.setEnabled(false);
        tfmobno.setEnabled(false);
        // tfdept.setEnabled(false);
        // tfprojname.setEnabled(false);
        tfdob.setEnabled(false);
        qual.setEnabled(false);
        gen.setEnabled(false);
        color1.setEnabled(false);
        // design.setEnabled(false);

      }

    } else if (ae.getSource() == bclose) {
      dispose();
    }

  }

  int searching(int eid) {
    int chk = 0;
    try {
      int v1 = 0;
      String v2 = "", v3 = "", v4 = "", v5 = "", v6 = "", v7 = "", v8 = "", v9 = "", v10 = "", v11 = "";

      while (rs.next()) {
        v1 = rs.getInt(1);
        v2 = rs.getString(2);
        v3 = rs.getString(3);
        v4 = rs.getString(4);
        v5 = rs.getString(5);
        v6 = rs.getString(6);
        v7 = rs.getString(7);
        v8 = rs.getString(8);
        // v9=rs.getString(9);
        // v10=rs.getString(10);
        // v11=rs.getString(11);

        if (v1 == eid) {
          tfid1.setText(String.valueOf(v1));
          tfname.setText(v2);
          taaddr.setText(v3);
          tfmobno.setText(v4);
          // tfdept.setText(v5);
          // tfprojname.setText(v6);
          tfdob.setText(v5);
          // tfgen.setText(v8);
          gen.select(v6);
          qual.select(v7);
          color1.select(v8);
          // design.select(v11);
          chk = 1;
          break;
        }
      }
      rs.first();
      rs.previous();
    } catch (SQLException se) {
      se.printStackTrace();
      System.out.println(se);
      JOptionPane.showMessageDialog(this, "Problems When Searching a Customer Record");
    }
    return (chk);
  }

  public static void main(String args[]) {
    Customer e = new Customer();
    e.setVisible(true);
    e.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });
  }
}
