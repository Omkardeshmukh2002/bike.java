import java.io.*;
import java.sql.*;

class OrderReport {
  OrderReport() {
    try {
      BufferedWriter bw = new BufferedWriter(new FileWriter("Orderrep.html"));
      bw.write("<html>");
      bw.write("<body bgcolor='pink'>");
      bw.write("<center>");
      bw.write("<h1>" + "Order Information Report" + "</h1>");
      bw.write("<table border=3 cellspacing=5 cellpadding=0>");
      bw.write("<tr>");
      bw.write("<th>" + "id" + "</th>");
      bw.write("<th>" + "bikename" + "</th>");
      bw.write("<th>" + "quantity" + "</th>");
      bw.write("<th>" + "colour" + "</th>");
      bw.write("</tr>");

      try {
        Connection con;
        Statement st;
        ResultSet rs;
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost/bike_selling_system", "root", "12345678");
        // con=DriverManager.getConnection("jdbc:odbc:College");
        st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        rs = st.executeQuery("select * from Order1");
        while (rs.next()) {
          bw.write("<tr>");
          bw.write("<td>" + rs.getInt(1) + "</td>");
          bw.write("<td>" + rs.getString(2) + "</td>");
          bw.write("<td>" + rs.getString(3) + "</td>");
          bw.write("<td>" + rs.getString(4) + "</td>");
          bw.write("</tr>");
        }
      } catch (Exception se) {
      }
      bw.write("</table>");
      bw.write("</center>");
      bw.write("</body>");
      bw.write("</html>");
      bw.close();
      Runtime rt = Runtime.getRuntime();
      rt.exec("Explorer Orderrep.html");
    } catch (IOException ie) {
    }
  }

  public static void main(String args[]) {
    OrderReport cr = new OrderReport();
  }
}
