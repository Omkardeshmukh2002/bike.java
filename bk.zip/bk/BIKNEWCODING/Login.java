import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class Login extends Frame implements ActionListener
{
   Label ltitle,ltitle1,luname,lpwd,llogin;
   TextField tfuname,tfpwd;
   Font f1,f2,f3,f4;
   Button blogin,bexit;
    public Login()
    {
      setSize(800,700);
      setVisible(true);
      setBackground(Color.pink);
      setTitle("Login Form");
      setLayout(null); 
      f1=new Font("Arial Black",Font.BOLD,34);
      f2=new Font("Arial",Font.BOLD,32);
      f3=new Font("Candara",Font.BOLD,24);
      f4=new Font("Arial",Font.BOLD,16);
     // f5=new Font("Times new Roman",Font.BOLD,30);
      ltitle=new Label("WEL-COME TO");
      ltitle.setFont(f1);
      ltitle.setForeground(Color.blue);
      ltitle1=new Label("BIKE SELLING SYSTEM");
      ltitle1.setFont(f2);
      ltitle1.setForeground(Color.yellow);

      luname=new Label("Username");
      luname.setFont(f3);

      lpwd=new Label("Password");
      lpwd.setFont(f3);

      llogin=new Label("Login");
      llogin.setFont(f3);
      llogin.setForeground(Color.green);
      
      tfuname=new TextField();
      tfpwd=new TextField();
      tfpwd.setEchoChar('*');
      tfuname.setFont(f4);
      tfpwd.setFont(f4);
      blogin=new Button("Login");
      blogin.setFont(f3);
      bexit=new Button("Exit");
      bexit.setFont(f3);
      add(ltitle);
      add(ltitle1);
      add(luname);
      add(lpwd);
      add(llogin);
      add(tfuname);
      add(tfpwd);
      add(blogin);
      blogin.addActionListener(this);
      add(bexit);
      bexit.addActionListener(this);
       ltitle.setBounds(300,50,300,30);
       ltitle1.setBounds(220,90,600,50);
       llogin.setBounds(330,140,80,30);
       JLabel jl=new JLabel(new ImageIcon("sdfghjk.jpg"));
       add(jl);
       jl.setBounds(100,50,500,500);
       luname.setBounds(200,480,150,30);
       tfuname.setBounds(370,480,180,30);
       lpwd.setBounds(200,530,150,30);
       tfpwd.setBounds(370,530,180,30);
       blogin.setBounds(250,600,80,30);
       bexit.setBounds(350,600,80,30);
      
    }

public void actionPerformed(ActionEvent ae)
{  
   if(ae.getSource()==blogin)
   {   
                  
               if((tfuname.getText().equals("Bike")) &&(tfpwd.getText().equals("System")))
                 {
                    JOptionPane.showMessageDialog(this,"Login Successfully");
                       new MainFrame();
                           dispose();
                     }
                 else
	{
      	JOptionPane.showMessageDialog(this,"We are NOT a valid user");
     	}
   }
  
  if(ae.getSource()==bexit)
{
dispose();
}
}   
    public static void main(String args[])
    {
     Login log=new Login();
     log.addWindowListener
     (
        new WindowAdapter()
         {
            public void windowClosing(WindowEvent we)
            {
                  System.exit(0);
             }
          }
      );
    }
}