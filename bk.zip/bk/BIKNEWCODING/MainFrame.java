import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

class MainFrame extends JFrame implements ActionListener {
	JMenuBar bar;
	JMenu m, r;
	JMenuItem amt, user, emp, sup, time, reg, bill, close, custreport, facilityreport, locationreport, employeereport,
			amountreport, billreport, orderreport;

	MainFrame() {
		bar = new JMenuBar();
		m = new JMenu("File");
		user = new JMenuItem("Customer");
		emp = new JMenuItem("Bike");
		sup = new JMenuItem("Supplier");
		time = new JMenuItem("Stocks");
		reg = new JMenuItem("Order");
		amt = new JMenuItem("Quotation");
		bill = new JMenuItem("Bill");

		close = new JMenuItem("Close");
		m.setMnemonic('F');
		user.addActionListener(this);
		emp.addActionListener(this);
		sup.addActionListener(this);
		time.addActionListener(this);
		reg.addActionListener(this);
		amt.addActionListener(this);
		bill.addActionListener(this);

		close.addActionListener(this);
		m.add(user);
		m.add(emp);
		m.add(sup);
		m.add(time);
		m.add(reg);
		m.add(amt);
		m.add(bill);

		bar.add(m);
		// setJMenuBar(bar);

		r = new JMenu("Report");
		custreport = new JMenuItem(" CustReport");
		employeereport = new JMenuItem(" BikeReport");
		facilityreport = new JMenuItem("SupplierReport");
		locationreport = new JMenuItem("StocksReport");
		amountreport = new JMenuItem("OrderReport");
		billreport = new JMenuItem("QuotationReport");
		orderreport = new JMenuItem("BillReport");

		close = new JMenuItem("Close");
		r.setMnemonic('R');
		custreport.addActionListener(this);
		employeereport.addActionListener(this);
		facilityreport.addActionListener(this);
		amountreport.addActionListener(this);
		locationreport.addActionListener(this);
		billreport.addActionListener(this);
		orderreport.addActionListener(this);

		close.addActionListener(this);
		r.add(custreport);
		r.add(employeereport);
		r.add(facilityreport);
		r.add(amountreport);
		r.add(locationreport);
		r.add(billreport);
		r.add(orderreport);

		r.add(close);
		bar.add(r);

		JLabel jl = new JLabel(new ImageIcon("1407164207_96469.jpg"));
		add(jl);
		jl.setBounds(100, 50, 500, 500);

		setContentPane(new JLabel(new ImageIcon("bgimg1.jpg")));
		setJMenuBar(bar);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 700);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == user)
			new Customer();

		else if (e.getSource() == emp)
			new Bike();

		else if (e.getSource() == sup)
			new Supplier();

		else if (e.getSource() == time)
			new Stocks();

		else if (e.getSource() == reg)
			new Order();

		else if (e.getSource() == amt)
			new Quotation();

		else if (e.getSource() == bill)
			new Bill();

		if (e.getSource() == custreport)
			new CustReport();

		else if (e.getSource() == employeereport)
			new BikeReport();

		else if (e.getSource() == billreport)
			new QuotationReport();

		else if (e.getSource() == orderreport)
			new BillReport();

		else if (e.getSource() == facilityreport)
			new SupplierReport();

		else if (e.getSource() == amountreport)
			new OrderReport();

		else if (e.getSource() == locationreport) {
			new StocksReport();
		}

		// else
		if (e.getSource() == close)
			dispose();
	}

	public static void main(String args[]) {
		new MainFrame();
	}
}