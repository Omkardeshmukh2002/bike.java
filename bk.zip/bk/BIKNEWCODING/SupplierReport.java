import java.io.*;
import java.sql.*;

class SupplierReport {
  SupplierReport() {
    try {
      BufferedWriter bw = new BufferedWriter(new FileWriter("Suprep.html"));
      bw.write("<html>");
      bw.write("<body bgcolor='pink'>");
      bw.write("<center>");
      bw.write("<h1>" + "Supplier Information Report" + "</h1>");
      bw.write("<table border=3 cellspacing=5 cellpadding=0>");
      bw.write("<tr>");
      bw.write("<th>" + "Sid" + "</th>");
      bw.write("<th>" + "Supname" + "</th>");
      bw.write("<th>" + "Address" + "</th>");
      bw.write("<th>" + "mobileno" + "</th>");
      bw.write("<th>" + "Supdob" + "</th>");
      bw.write("<th>" + "gender" + "</th>");
      bw.write("<th>" + "Biketype" + "</th>");
      bw.write("<th>" + "color" + "</th>");
      bw.write("</tr>");

      try {
        Connection con;
        Statement st;
        ResultSet rs;
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost/bike_selling_system", "root", "12345678");
        // con=DriverManager.getConnection("jdbc:odbc:College");
        st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        rs = st.executeQuery("select * from Supplier");
        while (rs.next()) {
          bw.write("<tr>");
          bw.write("<td>" + rs.getInt(1) + "</td>");
          bw.write("<td>" + rs.getString(2) + "</td>");
          bw.write("<td>" + rs.getString(3) + "</td>");
          bw.write("<td>" + rs.getString(4) + "</td>");
          bw.write("<td>" + rs.getString(5) + "</td>");
          bw.write("<td>" + rs.getString(6) + "</td>");
          bw.write("<td>" + rs.getString(7) + "</td>");
          bw.write("<td>" + rs.getString(8) + "</td>");

          bw.write("</tr>");
        }
      } catch (Exception se) {
      }
      bw.write("</table>");
      bw.write("</center>");
      bw.write("</body>");
      bw.write("</html>");
      bw.close();
      Runtime rt = Runtime.getRuntime();
      rt.exec("Explorer Suprep.html");
    } catch (IOException ie) {
    }
  }

  public static void main(String args[]) {
    SupplierReport cr = new SupplierReport();
  }
}
